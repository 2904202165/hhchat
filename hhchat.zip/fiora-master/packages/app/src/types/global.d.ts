declare module '@react-native-toolkit/triangle';
declare module 'react-native-dialog';

declare module '*.png';
