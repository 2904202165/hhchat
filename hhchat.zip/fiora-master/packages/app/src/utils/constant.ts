export const referer = 'https://fiora.suisuijiang.com/';
