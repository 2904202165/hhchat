import Dropdown from 'rc-dropdown';
import 'rc-dropdown/assets/index.css';

import './Dropdown.less';

export default Dropdown;
