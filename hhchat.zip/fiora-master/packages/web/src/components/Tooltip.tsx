import Tooltip from 'rc-tooltip';
import 'rc-tooltip/assets/bootstrap.css';

import './Tooltip.less';

export default Tooltip;
