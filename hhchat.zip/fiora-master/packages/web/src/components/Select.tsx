import Select, { Option, OptGroup } from 'rc-select';
import 'rc-select/assets/index.css';

export { Select, Option, OptGroup };
