import Loading from 'react-loading';

export default Loading;
